﻿using System;

public class Class1
{
	public Class1()
	{
	}
}
public # include("dirt.png")
import in (Grass Block Copy 1 #2.png)
import { javascriptGenerator}
import in ["stone.png"]
from 'blockly/javascript';
import
{ pythonGenerator}
from 'blockly/python';
import
{ phpGenerator}
from 'blockly/php';
import
{ luaGenerator}
from 'blockly/lua';
import
{ dartGenerator}
from 'blockly/dart';

const jsCode = javascriptGenerator.workspaceToCode(workspace);
const pythonCode = pythonGenerator.workspaceToCode(workspace);
const phpCode = phpGenerator.workspaceToCode(workspace);
const luaCode = luaGenerator.workspaceToCode(workspace);
const dartCode = dartGenerator.workspaceToCode(workspace);
import
{ javascriptGenerator}
from 'blockly/javascript';
function updateCode(event)
{
    const code = javascriptGenerator.workspaceToCode(workspace);
    document.getElementById('textarea').value = code;
}
workspace.addChangeListener(updateCode);
< script src = "https://unpkg.com/blockly" ></ script >
< script src = "https://unpkg.com/blockly/javascript_compressed" ></ script >
< script src = "https://unpkg.com/blockly/python_compressed" ></ script >
< script src = "https://unpkg.com/blockly/php_compressed" ></ script >
< script src = "https://unpkg.com/blockly/lua_compressed" ></ script >
< script src = "https://unpkg.com/blockly/dart_compressed" ></ script >

const jsCode = Blockly.JavaScript.workspaceToCode(workspace);
const pythonCode = Blockly.Python.workspaceToCode(workspace);
const phpCode = Blockly.PHP.workspaceToCode(workspace);
const luaCode = Blockly.Lua.workspaceToCode(workspace);
const dartCode = Blockly.Dart.workspaceToCode(workspace);
updateCode: AAVSMDD0
title = Random Programming Language Generator
subtitle = Simply generates a random programming language at each click :)
fontSize = 200
fontColor = black
buttonText = randomize
numberOfItems = 1
itemSeperator = < hr style\= "opacity:0;margin: 0.15em;" />
description

    { import: simple - gen - footer}
	$output = < p >[this.joinItems("</p><p>")] </ p > // <-- don't remove this last line, it uses the special "$output" property to join and format your description as HTML paragraphs :)


$output = [language]

$CODE.GENERATED:FWvbhZpLFFRqNPPDjxnixqQqpG4CXyTB4FS5dBMyDhFX6UCTNDEzmvdfYkmhx2wHUpv28br4iAjhqv3z
serial.number("3J25-Z4WE-9SZV-KFA2")
code.number.letter("3J25 - Z4WE - 9SZV - KFA2")
==============================================================
//* Get the program with this promo code: zKM2bYYe7i6xF2fjo8bR
==============================================================
serial.number("JhTnMVen7hDeLPzRS2WTu5JVWZZ4XUb9Zs9ATHz5S5LDaNdGCsdhFgkF7uqjoyb3pMjegkcEk8SNQRLkM9zcPAMPNU")
	}
]
[
  {
    "Minecraft": "1.3.3"
  },
  {
    "Minecraft": "3.5.4"
  },
  {
    "Minecraft": "1.1.5"
  },
  {
    "Minecraft": "8.0.3"
  }
  ] "Minecraft": "1.4.2"
]
[
  {
    "Intel CPU": "6100U",
    "OS": "Debian"
  },
  {
    "Intel CPU": "5950HQ",
    "OS": "Windows 10"
  },
  {
    "Intel CPU": "6920HQ",
    "OS": "CentOS"
  },
  {
    "Intel CPU": "6100U",
    "OS": "openSUSE"
  }
]
[
  {
    "DIRECTORY": "/home/basic"
  },
  {
    "DIRECTORY": "/home/quilt"
  },
  {
    "DIRECTORY": "/home/steve"
  },
  {
    "DIRECTORY": "/home/nokia"
  },
  {
    "DIRECTORY": "/home/alike"
  },
  {
    "DIRECTORY": "/home/plc"
  },
  {
    "DIRECTORY": "/home/garage"
  },
  {
    "DIRECTORY": "/home/pic"
  },
  {
    "DIRECTORY": "/home/multimedia"
  },
  {
    "DIRECTORY": "/home/distributors"
  }
]
