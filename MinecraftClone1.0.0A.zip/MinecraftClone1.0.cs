﻿using System;

public class Class1
{
	public Class1(1)
}
{
main:args
[]args*byte:(any)
value:-0-
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
echo 0
{
switch(0) -*if = (10-bit integer)
 = ("_CODE_BASE_")
echo 0000000000FFFFFF
using Memory; 000001000000FFF; ("800KB")
using Memory; 000002000000FFF; ("800KB")
using Memory; 000003000000FFF; ("800KB")
object(entity) ;= Zombie_Entity_Entry0 = ("behavior") <"bad">
object(entity) ;= Skeleton_Entity_Entry1 = ("behavior") <"bad"> ("kill_sound: C:\Users\declan.murphy0002\Downloads\voice(4).wav")
object(entity) ;= Blaze_Entity_Entry2 = ("behavior") < "bad" > ("kill_sound: C:\Users\declan.murphy0002\Downloads\voice(3).wav")
object(entity) ;= Cat_Entity_Entry = ("behavior") <"bad"> ("kill_sound:  C:\Users\declan.murphy0002\Downloads\\voice(5).wav")
object(block)  ;= Dirt_Block_Entry = ("block_break_sound"): ("C:\Users\declan.murphy0002\Downloads\voice(1).wav")
object(block)  ;= Grass_Block-Entry =("block_break_sound"): ("C:\Users\declan.murphy0002\Downloads\voice(6).wav")
object(item)   ;= Chocolate_Food_Item_Entry("food_eat_sound: C:\Users\declan.murphy0002\Downloads\voice(7).wav")
object(block)  ;= Stone_Block_Entry("block_break_sound: C:\\Users\\declan.murphy0002\\Downloads\\voice.wav")
import { javascriptGenerator}
        from 'blockly/javascript';
        import { pythonGenerator}
        from 'blockly/python';
        import { phpGenerator}
        from 'blockly/php';
        import { luaGenerator}
        from 'blockly/lua';
        import { dartGenerator}
        from 'blockly/dart';

        const jsCode = javascriptGenerator.workspaceToCode(workspace);
        const pythonCode = pythonGenerator.workspaceToCode(workspace);
        const phpCode = phpGenerator.workspaceToCode(workspace);
        const luaCode = luaGenerator.workspaceToCode(workspace);
        const dartCode = dartGenerator.workspaceToCode(workspace);
        import { javascriptGenerator}
        from 'blockly/javascript';
        function updateCode(event)
        {
            const code = javascriptGenerator.workspaceToCode(workspace);
            document.getElementById('textarea').value = code;
        }
        workspace.addChangeListener(updateCode);
< script src = "https://unpkg.com/blockly" ></ script >
< script src = "https://unpkg.com/blockly/javascript_compressed" ></ script >
< script src = "https://unpkg.com/blockly/python_compressed" ></ script >
< script src = "https://unpkg.com/blockly/php_compressed" ></ script >
< script src = "https://unpkg.com/blockly/lua_compressed" ></ script >
< script src = "https://unpkg.com/blockly/dart_compressed" ></ script >

const jsCode = Blockly.JavaScript.workspaceToCode(workspace);
        const pythonCode = Blockly.Python.workspaceToCode(workspace);
        const phpCode = Blockly.PHP.workspaceToCode(workspace);
        const luaCode = Blockly.Lua.workspaceToCode(workspace);
        const dartCode = Blockly.Dart.workspaceToCode(workspace);
    updateCode: AAVSMDD0
    title = Random Programming Language Generator
    subtitle = Simply generates a random programming language at each click :)
fontSize = 200
fontColor = black
buttonText = randomize
numberOfItems = 1
itemSeperator = < hr style\= "opacity:0;margin: 0.15em;" />
description

    { import: simple - gen - footer}
	$output = < p >[this.joinItems("</p><p>")] </ p > // <-- don't remove this last line, it uses the special "$output" property to join and format your description as HTML paragraphs :)


$output = [language]

$CODE.GENERATED:FWvbhZpLFFRqNPPDjxnixqQqpG4CXyTB4FS5dBMyDhFX6UCTNDEzmvdfYkmhx2wHUpv28br4iAjhqv3z
serial.number("3J25-Z4WE-9SZV-KFA2")
code.number.letter("3J25 - Z4WE - 9SZV - KFA2")
==============================================================
//* Get the program with this promo code: AwesomeSavings918757
==============================================================
serial.number("JhTnMVen7hDeLPzRS2WTu5JVWZZ4XUb9Zs9ATHz5S5LDaNdGCsdhFgkF7uqjoyb3pMjegkcEk8SNQRLkM9zcPAMPNU")
[
  {
    "Intel CPU": "6100U",
    "OS": "Debian"
  },
  {
    "Intel CPU": "5950HQ",
    "OS": "Windows 10"
  },
  {
    "Intel CPU": "6920HQ",
    "OS": "CentOS"
  },
  {
    "Intel CPU": "6100U",
    "OS": "openSUSE"
  }
]
[
  {
    "Hard Disk": "1024GB SSD",
    "OS": "FreeBSD"
  },
  {
    "Hard Disk": "1TB HDD",
    "OS": "Ubuntu"
  },
  {
    "Hard Disk": "256GB HDD",
    "OS": "Zorin"
  },
  {
    "Hard Disk": "512 GB HDD + 32GB SSD",
    "OS": "Kali"
  }
]3
ID_CODE;A45F8FUG8CA8DUZBC9GDJNDUF749H3G395MN4349029
================================================================================================================================================================================================
GUI_TEXTURES01:GUITEXTURE.PNG
GUI_TEXTURES:guitexture2.png
[
  {
    "IP Adress 1": "3.208.125.56:27039"
  },
  {
    "IP Adress 1": "174.1.76.235:16750"
  },
  {
    "IP Adress 1": "213.163.17.193:65375"
  },
  {
    "IP Adress 1": "213.137.138.203:13895"
  },
  {
    "IP Adress 1": "98.171.20.208:38142"
  },
  {
    "IP Adress 1": "202.73.59.150:5350"
  },
  {
    "IP Adress 1": "34.194.29.128:7904"
  },
  {
    "IP Adress 1": "136.210.147.195:19104"
  },
  {
    "IP Adress 1": "117.213.196.207:41514"
  },
  {
    "IP Adress 1": "84.24.19.27:8324"
  }
]
press_key "w" - define (w) 
"w" - define (n) - as "BREAK_BLOCK"
int "BREAK_BLOCK"
#press_key "a" - define (a) 
//press_key//define "a" - as "FORWARD"
//press_key//define "s" - as "backwards" - "s"
//press_key//define "d"  - as "<args - 03 - <-{->" - ""
